var products = [
{
    name:"tv",
    imgName:"",
    describtion:"",
    price:6500

},
{
    name:"Mobile",
    imgName:"",
    describtion:"",
    price:2500

},
{
    name:"Tshirts",
    imgName:"",
    describtion:"",
    price:1500

},
{
    name:"Toy",
    imgName:"",
    describtion:"",
    price:400

}
];

module.exports = {
    products:products
}