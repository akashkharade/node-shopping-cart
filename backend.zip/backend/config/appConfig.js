var config = {
    db:{
        connection:"mongodb://localhost:27017/shopping_cart"
    }
}

module.exports = config;